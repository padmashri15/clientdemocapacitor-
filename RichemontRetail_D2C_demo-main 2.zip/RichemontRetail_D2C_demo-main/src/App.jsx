import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg';
import 'bootstrap/dist/css/bootstrap.min.css'; 
import './App.css';

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import ProductList from './pages/ProductList';
import ProductDetails from './pages/ProductDetails';
import ProtectedRoute from './components/ProtectedRoute';
import Homepage from "./pages/HomePage";


function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     
<Router>
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/Home" element={<Homepage />} />
      <Route
        path="/products"
        element={
          <ProtectedRoute>
            <ProductList />
          </ProtectedRoute>
        }
      />
      <Route
        path="/products/:id"
        element={
          <ProtectedRoute>
            <ProductDetails />
          </ProtectedRoute>
        }
      />
      <Route path="*" element={<LoginPage />} />
    </Routes>
  </Router>

    </>
  )
}

export default App
