import React from 'react';
import { useParams, Link } from 'react-router-dom';
import ProductGallery from "../components/ProductGallery";
import ProductInfo from "../components/ProductInfo";

import Header from "../components/Header";

const ProductDetails = () => {
  const { id } = useParams();
  return (
    <div>
      <Header />

      <div className='container-wrap'>
        <div className='common-box p-common-box'>
          <div className='row'>
            <div className='col-sm-7 image-gallary'>
              <ProductGallery />
            </div>
            <div className='col-sm-5'>
              <ProductInfo />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;