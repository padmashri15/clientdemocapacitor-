import React from 'react';
import { Link } from 'react-router-dom';
import Header from "../components/Header";
import ListingFilter from '../components/ListingFilter';
import Products from '../components/Products';

const products = [
  { id: 1, name: 'Product A' },
  { id: 2, name: 'Product B' },
];

const ProductList = () => (
  <div>

    <Header />

    <div className='container-wrap'>
      <div className='row'>
        <div className='col-sm-2'>
           <ListingFilter/>
        </div>

        <div className='col-sm-10'>
            <Products/>
        </div>

      </div>
    </div>
  </div>
);

export default ProductList;