import React from 'react';
import { Link } from 'react-router-dom';
import Header from "../components/Header";
import TaskBriefings from "../components/TaskBriefings";
import HeroBanner from "../components/HeroBanner";
import YourClients from "../components/YourClients";
import EventCalender from '../components/EventCalender';

const Homepage = () => (
    <div>

        <Header />

        <div className='container-wrap'>
            <div className='row'>
                <div className='col-sm-9'><div className='common-box'>
                    <div className='d-flex justify-content-between align-items-end'>
                        <h2>Hi, Alexandre</h2>
                        <div className='loc_section'>
                            <span className='d-flex align-items-center justify-content-between'>
                                <span><img src="../../distance.png" alt="" /></span>
                                <p className='m-0'>175-177 New Bond St, London<br /> W1S 4RN, United Kingdom</p>
                            </span>
                        </div>
                    </div>
                    <div className='p-2'>
                        <HeroBanner />
                    </div>
                    <div className='row'>
                        <div className='col-sm-8'>
                            <TaskBriefings />
                        </div>
                        <div className='col-sm-4'>
                            <YourClients />
                        </div>
                    </div>
                </div></div>
                <div className='col-sm-3'>
                    <div className='common-box'>
                        <EventCalender />
                    </div>
                </div>
            </div>
        </div>

    </div>
);

export default Homepage;