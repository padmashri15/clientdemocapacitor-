import React from 'react';
import { useNavigate } from 'react-router-dom';

const LoginPage = ( cartier_logo_1 = "../../logo.png",
  login_title = "EMPLOYEE LOGIN",
  ellipse_1 = "../../user_img1.png",
  name = "Alexandre Dubois",
  designation = "Sales Associate",
  ellipse_1_1 = "../../user_img2.png",
  name_1 = "Isabelle Moreau",
  designation_1 = "Boutique Manager",
  name_2 = "ADD NEW",) => {
  const navigate = useNavigate();

  const handleLogin = () => {
    // Simulate login
    localStorage.setItem('auth', 'true');
    navigate('/Home');
  };

  return (
    <div className='card_login'>
    <div className="cardLogin">
      <div className="logoContainer">
        <img className="cartierLogo1" src="../../logo.png" alt="" />
        <div className="dividerContainer">
          <div className="line2"></div>
          <p className="loginTitle">{login_title}</p>
          <div className="line2"></div>
        </div>
      </div>
      <div className="employeeList">
        <div className="profile">
          <img className="ellipse1" src={ellipse_1} />
          <div className="nameDesignamtion">
            <p className="name2">{name}</p>
            <p className="designation">{designation}</p>
          </div>
        </div>
        <div className="profile2">
          <img className="ellipse1" src={ellipse_1_1} />
          <div className="nameDesignamtion2">
            <p className="name4">{name_1}</p>
            <p className="designation2">{designation_1}</p>
          </div>
        </div>
        <div className="btnSecondaryAddNew" onClick={handleLogin}>
          <div className="icnAdd">
            <img src="../../add_2.png" alt=""/>
            {/* <WUIcon color="#262626" id="Add2" name="Add2" size={24} /> */}
          </div>
          <p className="name5">{name_2}</p>
        </div>
      </div>
    </div>
    </div>
  );
};

export default LoginPage;