import React, { useState } from 'react'

function ProductInfo() {
    const [showToggle, setToggle] = useState(false);
    return (
        <>
            <div className='product_detail'>
                <div className='d-flex justify-content-between'>
                    <div className='title'>LOVE Unlimited Bracelet, flexible</div>
                    <div className='d-flex'>
                        <a href="#"><img src="../../shared_Bookmark.svg" alt="" /></a>&nbsp;&nbsp;
                        <a href="#"><img src="../../BookmarkContainer.svg" alt="" /></a>
                    </div>
                </div>

                <div className='p_btn_row pt-2 pb-2'>
                    <button className='active'>Product Description</button>
                    <button>The Story</button>
                    <button>Certifications</button>
                </div>
                <p>The LOVE collection began with the iconic bracelet created in New York in 1969. An expression of Cartier's design vision, this oval bracelet can be identified by its radical, innovative motif that dares to show its screws. Above and beyond its design, LOVE is a collection, a physical embodiment of feelings.</p>

                <div className='thumb_section d-flex justify-content-between'>
                    <div className='d-flex '>

                        <div className='mr-2'><img src="../../Productthumnb1.png" alt="" />
                            <div><small>Rose Gold</small></div>
                        </div>
                        <div className='mr-2'><img src="../../Productthumnb.png" alt="" />
                            <div><small>Yellow Gold</small></div>
                        </div>
                        <div className=''><img src="../../Productthumnb2.png" alt="" />
                            <div><small>White Gold</small></div>
                        </div>

                    </div>
                    <div className=''>
                        <h2>FIND YOUR SIZE</h2>
                        <select className='form-control'>
                            <option>16cm - AVAILABLE</option>
                        </select>
                    </div>
                </div>

                <div className='Add-Engraving'>
                    <div className='d-flex justify-content-between align-items-center'>
                        <div className='d-flex align-items-center'>
                            <div className='mr-2'><img src="../../stylus_pen.svg" alt="" /></div>
                            <div><h6>Add Engraving</h6>
                                <div>Add a personal message</div></div>
                        </div>

                        <div className=''>
                            <img src="../../keyboard_arrow_right.svg" alt="" />
                        </div>
                    </div>
                </div>


                <div className='price-container mt-4'>
                    <div className='d-flex  justify-content-between'>
                        <h6 className='d-flex'><span className='pr-title'>€9,750</span> &nbsp;&nbsp;

                            <div className='coutry-drop'>

                                <div className='' onClick={() => setToggle(true)}>  <img className="b-blue cur" src="../../CountryContainer.svg" alt="" /></div>

                                {showToggle &&
                                    <div className='coutry-menu'>
                                        <div className=''>
                                            <div className='d-flex justify-content-between'>
                                                <div className=''>
                                                    <label>Price Calculator</label>&nbsp;
                                                    <select className='cout-dropdown'><option>Eur</option>
                                                        <option>Eur</option>
                                                    </select>

                                                </div>
                                                <div className=''><span onClick={() => setToggle(false)} className='cur'><img src="../../close.svg" alt="" /></span></div>
                                            </div>

                                            <div className='search-box'>
                                                <input type="text" placeholder='Search Country...' />
                                            </div>

                                            <strong>Europe</strong>
                                            <div className='d-flex justify-content-between mt-2 align-items-center'>
                                                <div className='flag-img'>
                                                    <img src="../../Flags/Flag1.png" />
                                                    Albania
                                                </div>
                                                <div className='price-rate'>
                                                    <label>€ 9,280</label>
                                                    <span className='rate down'>20%</span>
                                                </div>
                                            </div>

                                            <div className='d-flex justify-content-between mt-2 align-items-center'>
                                                <div className='flag-img'>
                                                    <img src="../../Flags/Flag2.png" />
                                                    Belgium
                                                </div>
                                                <div className='price-rate'>
                                                    <label>€ 9,980</label>
                                                    <span className='rate up'>20%</span>
                                                </div>
                                            </div>

                                            <div className='d-flex justify-content-between mt-2 align-items-center'>
                                                <div className='flag-img'>
                                                    <img src="../../Flags/Flag3.png" />
                                                    Croatia
                                                </div>
                                                <div className='price-rate'>
                                                    <label>€ 12,280</label>
                                                    <span className='rate up'>20%</span>
                                                </div>
                                            </div>

                                            <div className='d-flex justify-content-between mt-2 align-items-center'>
                                                <div className='flag-img'>
                                                    <img src="../../Flags/Flag4.png" />
                                                    Czech Republic
                                                </div>
                                                <div className='price-rate'>
                                                    <label>€ 8,280</label>
                                                    <span className='rate down'>20%</span>
                                                </div>
                                            </div>

                                            <div className='d-flex justify-content-between mt-2 align-items-center'>
                                                <div className='flag-img'>
                                                    <img src="../../Flags/Flag5.png" />
                                                    Estonia
                                                </div>
                                                <div className='price-rate'>
                                                    <label>€ 10,280</label>
                                                    <span className='rate up'>20%</span>
                                                </div>
                                            </div>


                                            <div className='d-flex justify-content-between mt-2 align-items-center'>
                                                <div className='flag-img'>
                                                    <img src="../../Flags/Flag6.png" />
                                                    France
                                                </div>
                                                <div className='price-rate'>
                                                    <label>€ 9,280</label>
                                                    <span className='rate down'>20%</span>
                                                </div>
                                            </div>

                                            <div className='d-flex justify-content-between mt-2 align-items-center'>
                                                <div className='flag-img'>
                                                    <img src="../../Flags/Flag7.png" />
                                                    Greece
                                                </div>
                                                <div className='price-rate'>
                                                    <label>€ 8,280</label>
                                                    <span className='rate down'>20%</span>
                                                </div>
                                            </div>

                                            <div className='d-flex justify-content-between mt-2 align-items-center'>
                                                <div className='flag-img'>
                                                    <img src="../../Flags/Flag8.png" />
                                                    Iceland
                                                </div>
                                                <div className='price-rate'>
                                                    <label>€ 13,280</label>
                                                    <span className='rate up'>20%</span>
                                                </div>
                                            </div>

                                        </div>
                                    </div>}

                            </div>


                        </h6>

                        <div className='btn-row d-flex'>
                            <div>
                                {/* <button className=''>Check Availability</button> */}
                                <a href="#" className='mr-2'><img src="../../BookmarkContainer.svg" alt="" /></a>
                                <button className=' btn-active'>Add To CART</button>
                                <div className='text-end mt-2'>Available at S12R33</div>

                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </>
    )
}

export default ProductInfo
