// GLBViewer.tsx
import { Canvas } from '@react-three/fiber';
import { OrbitControls, useGLTF } from '@react-three/drei';


function Model({ url }) {
  const gltf = useGLTF(url);
  return <primitive object={gltf.scene} />;
}


export default function GLBViewer( {modelUrl}) {
  return (
    <Canvas style={{ height: '400px' }}>
      <ambientLight intensity={0.5} />
      <directionalLight position={[0, 0, 5]} />
      <OrbitControls />
      <Model url={modelUrl} />
    </Canvas>
  );
}