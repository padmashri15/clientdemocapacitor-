import React from 'react';
import { Link } from 'react-router-dom';

function ProductLookList() {
  return (
    <div className='mt-4 common-box shadow-none'>
        <div className='d-flex justify-content-between'>
<h4>Complete the Look</h4>
<div className=''>
    <span>SEE ALL <img src="../../keyboard_arrow_right.svg" alt=""/></span>
</div>

        </div>
    
      <div className='product-row'>
                    <Link to={`/products/1`} className='product-data product_simi'>
                        <div className='img-p'>
                            <img src="../../ProductImage1.svg" alt="" className='img-fluid' />
                            <span className='tag'>BESTSELLER</span>
                           
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>LOVE Unlimited Bracelet, flexible</h5>
                            <small>Rose Gold</small><br />
                            <strong>$248,000</strong>
                        </div>
                    </Link>

                   <a href="#" className='product-data product_simi'>
                        <div className='img-p'>
                            <img src="../../ProductImage2.svg" alt="" className='img-fluid' />
                            <span className='tag'>BESTSELLER</span>
                            
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Reflection de Cartier bracelet, diamonds</h5>
                            <small>White gold, diamonds</small><br />
                            <strong>$212,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data product_simi'>
                        <div className='img-p'>
                            <img src="../../ProductImage3.svg" alt="" className='img-fluid' />
                           
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Reflection de Cartier ring, diamonds</h5>
                            <small>White gold, diamonds</small><br />
                            <strong>109,000</strong>
                        </div>
                    </a>

                    </div>
    </div>
  )
}

export default ProductLookList
