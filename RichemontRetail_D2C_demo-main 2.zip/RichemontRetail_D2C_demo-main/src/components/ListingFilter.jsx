import React from 'react'

function ListingFilter() {
  return (
    <>
           <div className='common-box'>
            <h4>Filter Results</h4>
            <div className='filter_box'>
              <h6>Availability</h6>
              <p><input type="checkbox" /> At Boutique</p>
              <p><input type="checkbox" /> Online</p>
            </div>
            <div className='filter_box'>
              <h6>Category</h6>
              <p><input type="checkbox" />bracelets</p>
              <p><input type="checkbox" /> Rings</p>
              <p><input type="checkbox" /> necklaces</p>
              <p><input type="checkbox" /> ear-rings</p>
              <p><input type="checkbox" /> brooches</p>
              <p><a href="#">MORE</a></p>
            </div>
            <div className='filter_box'>
              <h6>Collection</h6>
              <p><input type="checkbox" />Panthère de Cartier</p>
              <p><input type="checkbox" /> Agrafe</p>
              <p><input type="checkbox" /> Cactus de Cartier</p>
              <p><input type="checkbox" /> Caresse d'orchidée par Cartier</p>
              <p><input type="checkbox" /> Faune et Flore de Cartier</p>
              <p><input type="checkbox" /> Coussin de Cartier</p>
              <p><input type="checkbox" /> Grain de Café</p>
              <p><a href="#">MORE</a></p>
            </div>

            <div className='filter_box'>
              <h6>Material</h6>
              <p><input type="checkbox" />Gold</p>
              <p><input type="checkbox" /> Silver</p>
              <p><input type="checkbox" /> Platinum</p>
              <p><input type="checkbox" /> White gold</p>

            </div>

            <div className='filter_box'>
              <h6>Size</h6>
              <p><input type="checkbox" />Gold</p>
              <p><input type="checkbox" /> Silver</p>
              <p><input type="checkbox" /> Platinum</p>


            </div>
          </div>
    </>
  )
}

export default ListingFilter
