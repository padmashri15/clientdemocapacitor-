import React from 'react'

function EventCalender() {
    return (
        <>
            <h2>October 2025</h2>
            <img src="../../calender-full.svg" alt="" className='img-fluid' />

            <div className='d-flex justify-content-between'>
                <label>Upcoming Reservations</label>
                <span><img src="../../icn-calendaradd.png" alt="" width={18} /></span>
            </div>

            <div className='up-reservation'>
                <div className='up-res'>
                    <p>11 Oct, 12:30 PM</p>
                    <div className='d-flex justify-content-between'>
                        <div className=''>
                            <h6>Ahmand Leary</h6>
                            <div className=''><img src="../../Products_1.png" alt="" />
                                <a href="#">+2 more</a></div>
                        </div>
                        <div className='text-end'>
                            <img src="../../icn-message.svg" alt="" />
                            <img src="../../icn-more.png" alt="" />
                        </div>
                    </div>
                </div>


                <div className='up-res'>
                    <p>11 Oct, 2:30 PM</p>
                    <div className='d-flex justify-content-between'>
                        <div className=''>
                            <h6>Jennifer Piquet</h6>
                            <div className=''><img src="../../Products_2.png" alt="" />
                            </div>
                        </div>
                        <div className='text-end'>
                            <img src="../../icn-message.svg" alt="" />
                            <img src="../../icn-more.png" alt="" />
                        </div>
                    </div>
                </div>


                <div className='up-res'>
                    <p>11 Oct, 2:30 PM</p>
                    <div className='d-flex justify-content-between'>
                        <div className=''>
                            <h6>Armand Otting</h6>
                            <div className=''><img src="../../Products_3.png" alt="" />
                            </div>
                        </div>
                        <div className='text-end'>
                            <img src="../../icn-message.svg" alt="" />
                            <img src="../../icn-more.png" alt="" />
                        </div>
                    </div>
                </div>

                <div className='up-res'>
                    <p>12 Oct, 3:00 PM</p>
                    <div className='d-flex justify-content-between'>
                        <div className=''>
                            <h6>Sofia Chen</h6>
                            <div className=''><img src="../../Products_3.png" alt="" />
                            </div>
                        </div>
                        <div className='text-end'>

                            <img src="../../icn-more.png" alt="" />
                        </div>
                    </div>
                </div>
                <div className='up-res'>
                    <p>12 Oct, 3:00 PM</p>
                    <div className='d-flex justify-content-between'>
                        <div className=''>
                            <h6>Sofia Chen</h6>
                            <div className=''><img src="../../Products_3.png" alt="" />
                            </div>
                        </div>
                        <div className='text-end'>

                            <img src="../../icn-more.png" alt="" />
                        </div>
                    </div>
                </div>
                <div className='up-res'>
                    <p>12 Oct, 3:00 PM</p>
                    <div className='d-flex justify-content-between'>
                        <div className=''>
                            <h6>Sofia Chen</h6>
                            <div className=''><img src="../../Products_3.png" alt="" />
                            </div>
                        </div>
                        <div className='text-end'>

                            <img src="../../icn-more.png" alt="" />
                        </div>
                    </div>
                </div>

            </div>
        </>
    )
}

export default EventCalender
