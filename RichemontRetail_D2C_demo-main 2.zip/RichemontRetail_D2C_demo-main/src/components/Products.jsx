import React from 'react'
import { Link } from 'react-router-dom';
function Products() {
    return (
        <>
            <div className='common-box'>
                <div className='d-flex justify-content-between'>
                    <h2>High Jewellery<br />
                        <span className='small'>83 Models</span></h2>
                    <div className='btn-data'>
                        <button className='selected'>Show Prices <img src="../../visibility.svg" alt="" /></button>&nbsp;
                        <button className='selected'>Your Briefings <img src="../../keyboard_arrow_down.svg" alt="" /></button>
                    </div>
                </div>


                <div className='product-row mt-4'>
                    <Link to={`/products/1`} className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage1.svg" alt="" className='img-fluid' />
                            <span className='tag'>BESTSELLER</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>LOVE Unlimited Bracelet, flexible</h5>
                            <small>Rose Gold</small><br />
                            <strong>$248,000</strong>
                        </div>
                    </Link>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage2.svg" alt="" className='img-fluid' />
                            <span className='tag'>BESTSELLER</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Reflection de Cartier bracelet, diamonds</h5>
                            <small>White gold, diamonds</small><br />
                            <strong>$212,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage3.svg" alt="" className='img-fluid' />
                            <span className='tag t_new'>NEW</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Reflection de Cartier ring, diamonds</h5>
                            <small>White gold, diamonds</small><br />
                            <strong>109,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage4.svg" alt="" className='img-fluid' />
                            <span className='tag t_coming'>COMING SOON</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Indomptables de Cartier bracelet</h5>
                            <small>Yellow gold, onyx, moonstone, black lacquer, tsavorite garnets</small><br />
                            <strong>$111,000 </strong>
                        </div>
                    </a>


                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage5.png" alt="" className='img-fluid' />
                            <span className='tag t_rem'>2 REMAININGS</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Panthère de Cartier bracelet, paved</h5>
                            <small>White gold, emerald and onyx</small><br />
                            <strong>$248,000 </strong>
                        </div>
                    </a>



                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage1.svg" alt="" className='img-fluid' />
                            <span className='tag'>BESTSELLER</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>LOVE Unlimited Bracelet, flexible</h5>
                            <small>Rose Gold</small><br />
                            <strong>$248,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage2.svg" alt="" className='img-fluid' />
                            <span className='tag'>BESTSELLER</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Reflection de Cartier bracelet, diamonds</h5>
                            <small>White gold, diamonds</small><br />
                            <strong>$212,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage3.svg" alt="" className='img-fluid' />
                            <span className='tag t_new'>NEW</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Reflection de Cartier ring, diamonds</h5>
                            <small>White gold, diamonds</small><br />
                            <strong>109,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage4.svg" alt="" className='img-fluid' />
                            <span className='tag t_coming'>COMING SOON</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Indomptables de Cartier bracelet</h5>
                            <small>Yellow gold, onyx, moonstone, black lacquer, tsavorite garnets</small><br />
                            <strong>$111,000 </strong>
                        </div>
                    </a>


                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage5.png" alt="" className='img-fluid' />
                            <span className='tag t_rem'>2 REMAININGS</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Panthère de Cartier bracelet, paved</h5>
                            <small>White gold, emerald and onyx</small><br />
                            <strong>$248,000 </strong>
                        </div>
                    </a>




                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage1.svg" alt="" className='img-fluid' />
                            <span className='tag'>BESTSELLER</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>LOVE Unlimited Bracelet, flexible</h5>
                            <small>Rose Gold</small><br />
                            <strong>$248,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage2.svg" alt="" className='img-fluid' />
                            <span className='tag'>BESTSELLER</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Reflection de Cartier bracelet, diamonds</h5>
                            <small>White gold, diamonds</small><br />
                            <strong>$212,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage3.svg" alt="" className='img-fluid' />
                            <span className='tag t_new'>NEW</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Reflection de Cartier ring, diamonds</h5>
                            <small>White gold, diamonds</small><br />
                            <strong>109,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage4.svg" alt="" className='img-fluid' />
                            <span className='tag t_coming'>COMING SOON</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Indomptables de Cartier bracelet</h5>
                            <small>Yellow gold, onyx, moonstone, black lacquer, tsavorite garnets</small><br />
                            <strong>$111,000 </strong>
                        </div>
                    </a>


                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage5.png" alt="" className='img-fluid' />
                            <span className='tag t_rem'>2 REMAININGS</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Panthère de Cartier bracelet, paved</h5>
                            <small>White gold, emerald and onyx</small><br />
                            <strong>$248,000 </strong>
                        </div>
                    </a>




                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage1.svg" alt="" className='img-fluid' />
                            <span className='tag'>BESTSELLER</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>LOVE Unlimited Bracelet, flexible</h5>
                            <small>Rose Gold</small><br />
                            <strong>$248,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage2.svg" alt="" className='img-fluid' />
                            <span className='tag'>BESTSELLER</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Reflection de Cartier bracelet, diamonds</h5>
                            <small>White gold, diamonds</small><br />
                            <strong>$212,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage3.svg" alt="" className='img-fluid' />
                            <span className='tag t_new'>NEW</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Reflection de Cartier ring, diamonds</h5>
                            <small>White gold, diamonds</small><br />
                            <strong>109,000</strong>
                        </div>
                    </a>

                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage4.svg" alt="" className='img-fluid' />
                            <span className='tag t_coming'>COMING SOON</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Indomptables de Cartier bracelet</h5>
                            <small>Yellow gold, onyx, moonstone, black lacquer, tsavorite garnets</small><br />
                            <strong>$111,000 </strong>
                        </div>
                    </a>


                    <a href="#" className='product-data'>
                        <div className='img-p'>
                            <img src="../../ProductImage5.png" alt="" className='img-fluid' />
                            <span className='tag t_rem'>2 REMAININGS</span>
                            <span className='bookmark'><img src="../../bookmark1.svg" alt="" /></span>
                        </div>
                        <div className='text-center p-detail pt-2'>
                            <h5>Panthère de Cartier bracelet, paved</h5>
                            <small>White gold, emerald and onyx</small><br />
                            <strong>$248,000 </strong>
                        </div>
                    </a>
                </div>
            </div>
        </>
    )
}

export default Products
