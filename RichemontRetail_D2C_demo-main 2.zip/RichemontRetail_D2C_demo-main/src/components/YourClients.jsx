import React from 'react'

function YourClients() {
    return (
        <>
            <div className='d-flex justify-content-between'>
                <h2>Your Clients</h2>
                <div><img src="../../adduser.svg" alt="" />
                    <img src="../../icn-calendar_1.svg" alt="" /></div>
            </div>
            <div className='btn-data'>
                <button className='active'>All <span>24</span></button>
                <button>Recently added <span>3</span></button>
            </div>

            <div className='client-info d-flex justify-content-between'>
                <div className='info-img'><img src="../../circle_1.svg" alt="" />
                    <span>NEW</span>
                </div>
                <div className='info_c'>
                    <h4>Mr. Chen</h4>
                    <div className='d-flex justify-content-between'>
                        <div className='mr-2'>
                            <span>Last Visit</span><br />
                            15 Oct, 2025
                        </div>
                        <div>
                            <span>Total Spend</span><br />
                            €45,000
                        </div>
                    </div>
                </div>
                <div className=''>
                    <img src="../../icn-more.png" alt="" />
                </div>
            </div>


            <div className='client-info d-flex justify-content-between'>
                <div className='info-img'><img src="../../circle_1.svg" alt="" />
                    <span className="c1">LOYAL</span>
                </div>
                <div className='info_c'>
                    <h4>Mr. Chen</h4>
                    <div className='d-flex justify-content-between'>
                        <div className='mr-2'>
                            <span>Last Visit</span><br />
                            15 Oct, 2025
                        </div>
                        <div>
                            <span>Total Spend</span><br />
                            €45,000
                        </div>
                    </div>
                </div>
                <div className=''>
                    <img src="../../icn-more.png" alt="" />
                </div>
            </div>



            <div className='client-info d-flex justify-content-between'>
                <div className='info-img'><img src="../../circle_1.svg" alt="" />
                    <span className="c1">LOYAL</span>
                </div>
                <div className='info_c'>
                    <h4>Mr. Chen</h4>
                    <div className='d-flex justify-content-between'>
                        <div className='mr-2'>
                            <span>Last Visit</span><br />
                            15 Oct, 2025
                        </div>
                        <div>
                            <span>Total Spend</span><br />
                            €45,000
                        </div>
                    </div>
                </div>
                <div className=''>
                    <img src="../../icn-more.png" alt="" />
                </div>
            </div>


            <div className='client-info d-flex justify-content-between'>
                <div className='info-img'><img src="../../circle_1.svg" alt="" />
                    <span className="c1">LOYAL</span>
                </div>
                <div className='info_c'>
                    <h4>Mr. Chen</h4>
                    <div className='d-flex justify-content-between'>
                        <div className='mr-2'>
                            <span>Last Visit</span><br />
                            15 Oct, 2025
                        </div>
                        <div>
                            <span>Total Spend</span><br />
                            €45,000
                        </div>
                    </div>
                </div>
                <div className=''>
                    <img src="../../icn-more.png" alt="" />
                </div>
            </div>


            <div className='client-info d-flex justify-content-between'>
                <div className='info-img'><img src="../../circle_1.svg" alt="" />
                    <span className="c1">LOYAL</span>
                </div>
                <div className='info_c'>
                    <h4>Mr. Chen</h4>
                    <div className='d-flex justify-content-between'>
                        <div className='mr-2'>
                            <span>Last Visit</span><br />
                            15 Oct, 2025
                        </div>
                        <div>
                            <span>Total Spend</span><br />
                            €45,000
                        </div>
                    </div>
                </div>
                <div className=''>
                    <img src="../../icn-more.png" alt="" />
                </div>
            </div>


            <div className='client-info d-flex justify-content-between'>
                <div className='info-img'><img src="../../circle_1.svg" alt="" />
                    <span className="c1">LOYAL</span>
                </div>
                <div className='info_c'>
                    <h4>Mr. Chen</h4>
                    <div className='d-flex justify-content-between'>
                        <div className='mr-2'>
                            <span>Last Visit</span><br />
                            15 Oct, 2025
                        </div>
                        <div>
                            <span>Total Spend</span><br />
                            €45,000
                        </div>
                    </div>
                </div>
                <div className=''>
                    <img src="../../icn-more.png" alt="" />
                </div>
            </div>


            <div className='client-info d-flex justify-content-between'>
                <div className='info-img'><img src="../../circle_1.svg" alt="" />
                    <span className="c1">LOYAL</span>
                </div>
                <div className='info_c'>
                    <h4>Mr. Chen</h4>
                    <div className='d-flex justify-content-between'>
                        <div className='mr-2'>
                            <span>Last Visit</span><br />
                            15 Oct, 2025
                        </div>
                        <div>
                            <span>Total Spend</span><br />
                            €45,000
                        </div>
                    </div>
                </div>
                <div className=''>
                    <img src="../../icn-more.png" alt="" />
                </div>
            </div>
        </>
    )
}

export default YourClients
