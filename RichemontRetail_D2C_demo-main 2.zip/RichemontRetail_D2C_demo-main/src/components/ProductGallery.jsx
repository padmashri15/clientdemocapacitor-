import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import GLBViewer from '../components/GLBViewer';

import { Modal, Button } from 'react-bootstrap';

function ProductGallery() {

    const [showModal, setShowModal] = useState(false);

    const handleOpen = () => setShowModal(true);
    const handleClose = () => setShowModal(false)

    return (
        <>
            <Link to={`/products`} className='back-menu'><img src="../../BackButton.svg" alt="" /></Link>

            <div className='pro_gallery d-flex'>
                <div className='pro-thumb d-flex flex-column'>
                    <img src="../../Product_Gallery/product1_1.svg" alt="" className='img-fluid' />
                    <div className=''>
                        <div className='text-center mt-2'>
                            <span onClick={handleOpen}><img src="../../3DViewOption.svg" className="cur" alt="" /></span>&nbsp;&nbsp;
                            <img src="../../ARViewOption.svg" className="cur" alt="" />
                        </div>

                    </div>
                    <div className='d-flex align-self-end mt-4'>
                        <div><img src="../../Product_Gallery/product1_1_small.svg" className='img-fluid' alt="" /></div>
                        <div><img src="../../Product_Gallery/product1_2_small.svg" className='img-fluid' alt="" /></div>
                    </div>
                </div>
                <div className='pro-thumb-right '>
                    <span className='cur' onClick={handleOpen}> <img src="../../Product_Gallery/product1_play.svg" className='img-fluid' alt="" /></span>
                    <img src="../../Product_Gallery/product1_trial.svg" className='img-fluid' alt="" />
                </div>
            </div>
            {/* <img src="../../ImageGallery.svg" alt="" className='img-fluid' /> */}

            {showModal && <Modal show={showModal}>
                <Modal.Header>
                    <div className="d-flex justify-content-between model-title"> <h5>3D View</h5> <span className='cur' onClick={handleClose}><img src="../../close.svg" alt="" /></span></div>
                </Modal.Header>
                <Modal.Body>
                    <GLBViewer modelUrl="../../3d/TankLouisCartierwatchBrown.glb" />
                </Modal.Body>

            </Modal>
            }


        </>
    )
}

export default ProductGallery
