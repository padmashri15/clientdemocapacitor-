import React from 'react'

function HeroBanner() {
    return (
        <>
            <div className='hero_banner row'>
                <div className='col-sm-4'>
                    <img src="../../ProductImage.png" alt="" />
                </div>
                <div className='col-sm-8'>
                    <a href="#" className='arrow-shap'><img src="../../icn-chevleft.png" alt="" /></a>
                    <a href="#" className='arrow-shap a_right'><img src="../../icn-chevright.png" alt="" /></a>
                    <div className='banner-info'>
                        <span className='mark'>GLOBAL LAUNCH</span>
                        <h3>The 'Celestial' High Jewelry Collection</h3>
                        <p>The 'Celestial' collection officially launches today. All product details, pricing, and storytelling assets are now live in the catalog. A mandatory training article has been added to the Content Hub. Please review it before engaging with clients.</p>
                        <div className='btn-row d-flex'>
                            <button className='active'>VIEW TRAINING</button>
                            <button>VIEW CATALOG</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default HeroBanner
