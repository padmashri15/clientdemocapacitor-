import React from 'react'

function TaskBriefings() {
    return (
        <>
            <div className='d-flex justify-content-between mb-2'> <h2>Tasks & Briefings</h2>
                <div className='btn-data'>
                    <button className='active'>YOUR TASKS <span>4</span></button>&nbsp;
                    <button>Your Briefings <span>3</span></button>
                </div>
            </div>

            <div className='test-row'>
                <div className='d-flex justify-content-between'>
                    <span>Appointment Prep</span>
                    <div class="d-flex">
                        <span><img src="../../user_img2.png" width={24} alt="" /></span>&nbsp;
                        Janice
                    </div>
                </div>
                <div><p>Prepare for your 3 PM appointment with Ms. Garcia. Review her client profile, purchase history, and have the pieces from her wishlist ready for viewing.</p></div>
                <div className='d-flex justify-content-between'>
                    <div className='task-option'>
                        <a href="#"><img src="../../account_circle.svg" alt="" /> View Profile</a>
                        <a href="#"><img src="../../search_activity.svg" alt="" /> View History</a>
                        <a href="#"><img src="../../bookmark.svg" alt="" /> View Wishlist</a>
                    </div>
                    <div className=''><input type='radio' />Mark as Complete</div>
                </div>

            </div>


            <div className='test-row'>
                <div className='d-flex justify-content-between'>
                    <span>Follow Up</span>
                    <div class="d-flex">
                        <span><img src="../../user_img2.png" width={24} alt="" /></span>&nbsp;
                        Janice
                    </div>
                </div>
                <div><p>Follow up with Mr. Smith regarding the curated selection of watch straps you shared with him yesterday. A message template is available.</p></div>
                <div className='d-flex justify-content-between'>
                    <div className='task-option'>
                        <a href="#"><img src="../../account_circle.svg" alt="" /> View Profile</a>
                        <a href="#"><img src="../../chat.svg" alt="" /> View Template</a>

                    </div>
                    <div className=''><input type='radio' />Mark as Complete</div>
                </div>

            </div>


            <div className='test-row'>
                <div className='d-flex justify-content-between'>
                    <span>Product Stock</span>
                    <div class="d-flex">
                        <span><img src="../../user_img2.png" width={24} alt="" /></span>&nbsp;
                        Janice
                    </div>
                </div>
                <div><p>The 'Etoile' necklace from Ms. Chen's wishlist is now back in stock in our boutique. Contact the client to inform her of the availability.</p></div>
                <div className='d-flex justify-content-between'>
                    <div className='task-option'>
                        <a href="#"><img src="../../call_icon.svg" alt="" /> Contact Client</a>


                    </div>
                    <div className=''><input type='radio' />Mark as Complete</div>
                </div>

            </div>


            <div className='test-row'>
                <div className='d-flex justify-content-between'>
                    <span>Stocking</span>
                    <div class="d-flex">
                        <span><img src="../../user_img2.png" width={24} alt="" /></span>&nbsp;
                        Janice
                    </div>
                </div>
                <div><p>New shipment has arrived. Please scan and confirm the physical location of the items assigned to you in Drawer #4.1.</p></div>
                <div className='d-flex justify-content-between'>
                    <div className='task-option'>
                        <a href="#"><img src="../../account_circle.svg" alt="" /> View Profile</a>
                        <a href="#"><img src="../../search_activity.svg" alt="" /> View History</a>
                        <a href="#"><img src="../../bookmark.svg" alt="" /> View Wishlist</a>
                    </div>
                    <div className=''><input type='radio' />Mark as Complete</div>
                </div>

            </div>
        </>
    )
}

export default TaskBriefings
