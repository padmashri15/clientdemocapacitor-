import React from 'react';
import { Link } from 'react-router-dom';


export default function Header() {
    return (

        <header>
            <div className='container-header'>
            <div className='d-flex justify-content-between align-items-center'>
               <div className='d-flex justify-content-between align-items-center'>
                <div className='logo d-flex mr-4'>
                    <div className='p-2'><img src="../../hamburger_menu.png" /></div>
                    <Link to={`/login`}><img src="../../Cartier-logo 1.png" /></Link>
                </div>
                <div class="menu-links d-flex">
                    <Link to={`/products`} className='link text-center active'>
                        <img src="../../local_mall_hover.svg" />
                        <p>STORE</p>
                    </Link>
                    <div className='link text-center'>
                        <img src="../../warehouse.png" />
                        <p>STOCK</p>
                    </div>


                    <div className='link text-center'>
                        <img src="../../user_icons.png" />
                        <p>CLIENT</p>
                    </div>
                    <div className='link text-center'>
                        <img src="../../local_mall.png" />
                        <p>TASKS

                        </p>
                    </div>
</div>
</div>
                    <div className='search_section'>
                        <input type="text" placeholder='Search placeholder text' />
                    </div>
<div className='d-flex justify-content-between align-items-center'>
                    <div class="menu-links d-flex">
                        <div className='link text-center'>
                            <img src="../../qr_code_scanner.png" />
                            <p>SCAN CODE</p>
                        </div>
                        <div className='link text-center'>
                            <img src="../../notifications.png" />
                            <p>ALERTS</p>
                        </div>
                    </div>
                    <div className='profile-right text-end'>
                        <img src="../../user_profiel.png" width={40}/>
                        <span><img src="../../keyboard_arrow_down.png" alt=""/></span>
                        
                    </div>
                    </div>


                  </div>
            </div>
        </header>

    )
}
